import character
import koko

def maker(character_name):

    if character_name == "koko":
        koko.necromancer(character_name)
    else:
        character.orgin(character_name)
        character.stats(character_name)
