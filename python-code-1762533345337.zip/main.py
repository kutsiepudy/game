import character
print("Welcome adventurer")
print("Click enter to proceed")
input(">")
print("You are here for something special")
input(">")

import koko
import sheet
character_name = input("What is your character's name: ").lower()
sheet.maker(character_name)
print("Type yes or no")
start_game = input("Do you want to proceed: ").lower()

if start_game == "yes":
    print("Let us start the adventure.")
    input("> ")
    print("Please take the game seriously.")
elif start_game == "no":
    print("Then your beautiful creation will be discarded")
    exit()
else:
    print("Please try to be serious about the game.")
    input("> ")

import story
import story2
if character_name == "koko":
    character_name = "Koko"
    story.intro(character_name)
else:
    story2.intro(character_name)