import character
import random

def intro(character_name):
    print("The sun beats down on the Triboar Trail as your wagon creaks along the dusty road.")
    input(">")
    print(f"Your employer, Gundren Rockseeker, hired you, {character_name}, to deliver supplies to the frontier town of Phandalin.")
    input(">")
    print("You hum a tune as the oxen pull steadily forward… until something feels wrong.")
    input(">")
    print("Two dead horses lie sprawled across the path ahead—each with black-feathered arrows sticking out of them.")
    input(">")
    print("What do you do?")
    print("1. Approach carefully and investigate.")
    print("2. Draw your weapon and scan the trees.")
    print("3. Turn the wagon around—this looks bad.")
    choice = input("Choose 1–3 > ")

    if choice == "1":
        print("You step closer, eyes narrowed. Suddenly, a whizzing arrow cuts the air—it's an ambush!")
        goblin_ambush(character_name)
    elif choice == "2":
        print("You grip your weapon tight and look around. You spot movement in the brush—goblins!")
        goblin_ambush(character_name)
    elif choice == "3":
        print("You whip the oxen around, but too late—goblins spring from hiding! Arrows fly past your head!")
        goblin_ambush(character_name)
    else:
        print("Indecision costs you—arrows rain from the trees!")
        goblin_ambush(character_name)


def goblin_ambush(character_name):
    input(">")
    print("Roll for initiative!")
    initiative = int(input("Enter your d20 roll for initiative > "))
    goblin_initiative = random.randint(1, 20)

    if initiative > goblin_initiative:
        print("You act first!")
    elif initiative < goblin_initiative:
        print("The goblins go first!")
        print("Two goblins leap from the thicket, snarling and drawing shortbows.")
    else:
        print("A tie! You and the goblins act at the same time!")

    print("\nYou can:")
    print("1. Charge the nearest goblin.")
    print("2. Take cover behind the wagon and fire back.")
    print("3. Try to intimidate them into fleeing.")
    action = input("Choose 1–3 > ")

    if action == "1":
        print("You rush forward, weapon ready! Roll to hit.")
        roll = int(input("Enter your d20 roll > "))
        if roll >= 12:
            print("Your strike lands true! One goblin falls with a cry.")
        else:
            print("Your swing misses, and the goblin ducks aside!")
    elif action == "2":
        print("You dive behind the wagon and take aim.")
        roll = int(input("Enter your d20 roll > "))
        if roll >= 10:
            print("Your shot grazes a goblin! They screech and scatter into the woods.")
        else:
            print("Your shot goes wide, and arrows thud into the wagon!")
    elif action == "3":
        print("You shout with all your might, hoping to scare them off.")
        roll = int(input("Roll for Intimidation (d20 + Charisma) > "))
        if roll >= 13:
            print("The goblins freeze, then flee into the underbrush! You’ve survived the ambush!")
        else:
            print("They just laugh and attack anyway!")
    else:
        print("You hesitate—arrows strike the wagon! Take cover next time!")

    input(">")
    print("The dust settles. You’ve survived, but your employer’s trail leads off into the forest.")
    goblin_trail(character_name)


def goblin_trail(character_name):
    input(">")
    print("You examine the scene. The horses bear Gundren’s crest—these were his mounts.")
    input(">")
    print("You spot a set of small footprints leading into the woods. Goblins must’ve taken him.")
    print("\nWhat do you do?")
    print("1. Follow the goblin trail into the forest.")
    print("2. Stay with the wagon and rest before deciding.")
    print("3. Take supplies and continue toward Phandalin.")
    trail_choice = input("Choose 1–3 > ")

    if trail_choice == "1":
        print("You tighten your gear and slip into the forest, following the faint tracks.")
        print("The sounds of the forest close in—rustling leaves, dripping water, distant chatter…")
        input(">")
        print("After an hour, you spot a narrow path leading to a dark cave mouth hidden behind brambles.")
        input(">")
        print("This must be their hideout.")
        cragmaw_hideout(character_name)

    elif trail_choice == "2":
        print("You decide to make camp beside the wagon, gathering your strength.")
        input(">")
        print("The night passes uneasily. When dawn comes, the tracks are nearly gone…")
        print("You lost your chance to follow Gundren’s captors.")
        print("You continue to Phandalin, burdened by guilt.")
        input(">")
        print("THE END (for now).")
        return

    elif trail_choice == "3":
        print("You decide it’s too dangerous alone. You drive the wagon toward Phandalin to get help.")
        input(">")
        print("The road winds for hours until you see the first rooftops of a small frontier town.")
        print("Welcome to Phandalin.")
        print("A new chapter begins…")
        print("TO BE CONTINUED.")
        return

    else:
        print("You wait too long—something moves in the trees… and then everything goes black.")
        print("Game Over.")
        return


def cragmaw_hideout(character_name):
    input(">")
    print("The cave mouth yawns before you, cool air drifting out carrying the faint scent of blood and damp stone.")
    print("\nYou hear faint splashes deeper inside and the echo of goblin voices.")
    print("1. Sneak in quietly (Stealth check).")
    print("2. Charge in, weapon ready.")
    print("3. Call out to whoever’s inside.")
    choice = input("Choose 1–3 > ")

    if choice == "1":
        roll = int(input("Roll for Stealth (d20 + Dex) > "))
        if roll >= 12:
            print("You slip in silently, keeping to the shadows. The goblins don’t notice you… yet.")
            print("You see a small kennel with snarling wolves chained to a rock. One growls softly.")
        else:
            print("You trip over a loose stone—wolves start barking! The goblins shout in alarm!")
    elif choice == "2":
        print("You rush in yelling! The noise startles the goblins—but also the wolves in the corner!")
        print("Two wolves break loose and charge at you!")
        roll = int(input("Roll your attack (d20) > "))
        if roll >= 14:
            print("You fend one off and knock it aside—but more noise draws goblins from deeper in!")
        else:
            print("You’re bitten hard and stagger back! You retreat to the entrance!")
    elif choice == "3":
        print("You shout into the cave. The echo carries…")
        print("A mocking goblin voice answers: 'Come on in, meat!'")
        input(">")
        print("You realize that wasn’t the best move.")
    else:
        print("You freeze up, and time slips away—goblins spot you at the cave mouth!")

    input(">")
    print(f"Your journey continues, {character_name}. The mystery of Gundren’s disappearance deepens…")

def wolf_den(character_name):
    input("> ")
    print("You creep deeper into the cave. The growling grows louder.")
    print("Three wolves are chained to a stone column—eyes glinting in the dim light.")
    print("\nWhat do you do?")
    print("1. Try to calm the wolves (Animal Handling check).")
    print("2. Attack before they break free.")
    print("3. Sneak past quietly (Stealth check).")
    choice = input("Choose 1–3 > ")

    if choice == "1":
        roll = int(input("Roll for Animal Handling (d20 + Wisdom) > "))
        if roll >= 13:
            print("You speak softly and offer a scrap of food. The wolves calm down and let you pass.")
        else:
            print("The wolves snarl and tug at their chains—the noise echoes through the cave!")
    elif choice == "2":
        roll = int(input("Roll your attack (d20) > "))
        if roll >= 12:
            print("You take down a wolf quickly, but the others’ howls alert the goblins deeper inside!")
        else:
            print("Your swing misses, and the wolves snap dangerously close to your leg!")
    elif choice == "3":
        roll = int(input("Roll for Stealth (d20 + Dex) > "))
        if roll >= 14:
            print("You move quietly along the shadows, slipping past unnoticed.")
        else:
            print("A rock shifts underfoot—the wolves bark loudly! You’ve been heard!")
    else:
        print("You freeze up. The wolves lunge, and chaos erupts!")

    input("> ")
    print("You move deeper into the cavern, the air colder and thicker with tension.")
    goblin_guards(character_name)


def goblin_guards(character_name):
    input("> ")
    print("You reach a fork in the cave passage.")
    print("To the left, you hear dripping water. To the right, faint goblin chatter.")
    print("You sneak right and peek around the corner.")
    input("> ")
    print("Three goblins sit by a campfire, arguing over loot.")
    print("\nWhat will you do?")
    print("1. Sneak past them unnoticed (Stealth check).")
    print("2. Ambush them while they argue.")
    print("3. Try to trick them into thinking you’re their boss (Deception check).")
    choice = input("Choose 1–3 > ")

    if choice == "1":
        roll = int(input("Roll for Stealth (d20 + Dex) > "))
        if roll >= 15:
            print("You slip by like a shadow, unseen.")
        else:
            print("A pebble rolls under your boot—the goblins spot you! Combat begins!")
    elif choice == "2":
        roll = int(input("Roll to hit (d20) > "))
        if roll >= 12:
            print("You take one out before they can react! The others scatter into the dark!")
        else:
            print("You miss your strike! The goblins shout for reinforcements!")
    elif choice == "3":
        roll = int(input("Roll for Deception (d20 + Charisma) > "))
        if roll >= 13:
            print("They squint at you nervously. 'Uh, yes boss!' They leave the cave in a hurry!")
        else:
            print("They burst into laughter—then charge at you with blades drawn!")
    else:
        print("You hesitate, and one goblin notices you. Battle erupts!")

    input("> ")
    print("You press on deeper into the cave, where you hear faint cries for help.")
    captive_scene(character_name)


def captive_scene(character_name):
    input("> ")
    print("You find a rough wooden cage near a small campfire.")
    print("Inside, a bruised and bloodied man looks up weakly.")
    input("> ")
    print('"Help... please," he whispers. "My name is Sildar Hallwinter... they took Gundren north."')
    print("\nWhat do you do?")
    print("1. Free him immediately (Strength check).")
    print("2. Question him about what happened.")
    print("3. Ignore him and explore the cave first.")
    choice = input("Choose 1–3 > ")

    if choice == "1":
        roll = int(input("Roll for Strength (d20 + Mod) > "))
        if roll >= 10:
            print("You break the crude lock and help him out. He thanks you deeply.")
        else:
            print("You strain, but the lock holds. You’ll need another way.")
    elif choice == "2":
        print("You kneel beside him as he explains:")
        input("> ")
        print('"Gundren discovered a lost mine—something powerful. The goblins took him to Cragmaw Castle..."')
        input("> ")
        print('"Please, take me to Phandalin... I can help you find him."')
    elif choice == "3":
        print("You turn away, ignoring his plea. The man sighs in despair.")
    else:
        print("You stand there indecisively. Time is running short.")
    
    input("> ")
    print("You hear faint movement deeper inside—reinforcements may be coming!")
    print("You should leave soon.")
    aftermath(character_name)


def aftermath(character_name):
    input("> ")
    print("You emerge from the cave, sunlight blinding after the darkness inside.")
    input("> ")
    print("If you rescued Sildar, he leans on you for support as you walk back to the trail.")
    print("He speaks weakly: 'We must reach Phandalin. The Rockseeker brothers are in danger.'")
    input("> ")
    print("You nod, determination setting in. The road ahead will be long—but the adventure has only begun.")
    input("> ")
    print(f"Good work, {character_name}. You’ve completed Chapter 1 of the story.")
