def stats(character_name):
    print("Please give us your stats")
    print("You can only choose a number between 1-20")
    character_strength = int(input("What is your strength: "))
    character_dexterity = int(input("What is your dexterity: "))
    character_constitution = int(input("What is your constitution: "))
    character_intelligence = int(input("What is your intelligence: "))
    character_wisdom = int(input("What is your wisdom: "))
    character_charisma = int(input("What is your charisma: "))
    print("Here is your stat sheet"),
    print(f"Your name is {character_name}"),
    print(f"Strength: {character_strength}"),
    print(f"Dexterity: {character_dexterity}"),
    print(f"Constitution: {character_constitution}"),
    print(f"Intellogence: {character_intelligence}"),
    print(f"Wisdom: {character_wisdom}"),
    print(f"Charisma: {character_charisma}")
    return {
    "strength" : character_strength,
    "dexterity" : character_dexterity,
    "constitution" : character_constitution,
    "intellengence" : character_intelligence,
    "wisdom" : character_wisdom,
    "charisma" : character_charisma,
    }

def orgin(character_name):
    character_background = input("What is your character's background: ").lower()
    if character_background == "acolyte":
        character_religion = input("What is your characters religion: ")
        character_role = input("What is your characters role: ")
        return{
            "background" : character_background,
            "role" : character_role,
            "religion" : character_religion
        }
    else:
        character_religion = None
    character_role = input("What is your character's role: ")
    return{
        "background" : character_background,
        "role" : character_role
    }