import koko
import random
def intro(character_name):
    player_stats = koko.stats(character_name)
    print("You hear the faint sound of someone trying to wake you up.")
    input("> ")
    print("???:")
    print(f"Hey {character_name}, wake up!")
    input("> ")
    print("You see someone in front of you.")
    input("> ")
    print("It's Alicia.")
    input("> ")
    print("Alicia:")
    print(f"Hey {character_name}, is everything ok?")
    input("> ")

    print("Are you going to respond? (Yes or No)")
    respond = input("> ").strip().lower()
    if respond in ["yes", "y"]:
        print("You respond to her.")
    elif respond in ["no", "n"]:
        print("You continue to look at her silently.")
    else:
        print("That's not a valid response, but Alicia gives you a worried look anyway.")

    input("> ")
    print("Alicia:")
    print(f"You sure you're ok?")
    input("> ")
    print("Alicia:")
    print("You're worrying me.")
    input("> ")

    print("You have three choices:")
    print("1. Ignore her.")
    print("2. Convince her you're fine (Roll a persuasion check).")
    print("3. Tell her the truth.")
    while True:
        choice = input("Choose a number between 1-3: ").strip()
        if choice in ["1", "2", "3"]:
            break
        print("Please choose 1, 2, or 3.")

    if choice == "1":
        print("Alicia:")
        print("Hey!!! You can't just ignore me!")
    elif choice == "2":
        dice_roll = get_dice_roll("persuasion")
        if dice_roll < 13:
            print("Alicia:")
            print(f"{character_name}, you can’t convince me that you’re fine.")
        else:
            print("Alicia:")
            print("Ok, I believe you.")
    elif choice == "3":
        print("You tell her the truth.")
        input("> ")
        print("She looks concerned.")

    input("> ")
    print("Alicia:")
    print("We have to go, someone wants to see us.")
    input("> ")

    the_meeting(character_name, player_stats)


def the_meeting(character_name, player_stats):
    print("You and Alicia are walking to the castle together.")
    input("> ")
    print("You see the grand doors of the throne room ahead.")
    input("> ")
    print("You open them and step inside the grand hallway.")
    input("> ")

    print("Alicia:")
    print(f"Isn't it amazing, {character_name}?")
    input("> ")
    print("Alicia:")
    print("I wish I could live here.")
    input("> ")

    print("Do you respond? (Yes or No)")
    respond_2 = input("> ").strip().lower()
    if respond_2 in ["yes", "y"]:
        print(f"{character_name}:")
        print("Yeah, it does seem pretty cool.")
    elif respond_2 in ["no", "n"]:
        print("Alicia:")
        print("You’re awfully quiet today.")
    else:
        print("You say nothing, unsure of how to reply.")

    input("> ")
    print("???:")
    print("Pardon me.")
    input("> ")

    print("King Janoth III:")
    print("Are you the people I needed to see?")
    input("> ")
    print("King Janoth III:")
    print("Say, the one in grey, you look familiar.")
    input("> ")

    print("You have two options:")
    print("1. Try to recall if you’ve met him before (Roll a History check).")
    print("2. Try to deny who you are (Roll a Deception check).")

    choice_2 = get_choice(["1", "2"], "Choose 1 or 2: ")
    if choice_2 == "1":
        dice_roll = get_dice_roll("history")
        if dice_roll < 13:
            print(f"{character_name}:")
            print("I don’t think we’ve met, Sir.")
        else:
            print(f"{character_name}:")
            print("Ah, King Janoth III. A pleasure to meet you again.")
    elif choice_2 == "2":
        dice_roll = get_dice_roll("deception")
        if dice_roll < 13:
            print(f"{character_name}:")
            print("Sir, I think you must be mistaken.")
            input("> ")
            print("King Janoth III:")
            print("Nonsense! I know who you are.")
            input("> ")
            print("King Janoth:")
            print("I'm only kidding!")
        else:
            print(f"{character_name}:")
            print("Y’know, grey’s a common color in your kingdom.")
            input("> ")
            print("King Janoth III:")
            print("You’re right, my apologies.")
    
    input("> ")
    print("King Janoth III:")
    print("Anyway, I need your help with something.")
    input("> ")
    print("Follow me, we shan't waste time")
    the_quest(character_name, player_stats)


def the_quest(character_name, player_stats):
    print("King Janoth III:")
    print("You see, some sort of creature has attacked one of our farmlands.")
    input("> ")
    print("He walks into a room.")
    input("> ")
    print("King Janoth III:")
    print("Follow me please.")
    input("> ")
    print("As you guys follow, you see a bunch of soldiers and mages running around frantically.")
    input("> ")
    print("King Janoth III:")
    print("Say, I need a proper introduction.")
    input("> ")
    print("Are you going to introduce yourself? Yes or No")
    respond_3 = input("> ").strip().lower()
    if respond_3 in ["yes", "y"]:
        print(f"{character_name}:")
        print(f"I'm {character_name}, an Acolyte of holy magic")
    elif respond_3 in ["no", "n"]:
        print("You stood there, completely still.")
    else:
        print("You didn't understand the question.")
        input("> ")
        print("You stood there awkwardly.")
    input("> ")
    print("Alicia:")
    print("I'm Alicia, a noble of the Deans Family.")
    input("> ")
    print("King Janoth III:")
    print("Well then now that we have given ourselves a proper introduction...")
    input("> ")
    print("King Janoth III:")
    print("I know it may seem sudden...")
    input("> ")
    print("King Janoth III:")
    print("It's not everyday I hire random people.")
    input("> ")
    print("King Janoth III:")
    print("But the stakes are high and we need as much help as we can get.")
    input("> ")
    print("King Janoth III:")
    print("I've heard of your skills and thought you guys were eligable for this, quest...")
    input("> ")
    print("King Janoth III:")
    print("Are you guys up for it?")
    input("> ")
    print("You have 3 options.")
    print("Accept the quest.")
    print("Decline the quest.")
    print("Stay silent.")
    choice_3 = get_choice(["1", "2", "3"], "Choose between 1-3: ")
    if choice_3 == "1":
        print("King Janoth III:")
        print("Suprisingly easy to convince you guys.")
    elif choice_3 == "2":
        print("Alicia:")
        print(f"Oh come on {character_name}, we're gonna do it!")
    else:
        print("You continue to stand there.")
        input("> ")
        print("Alicia:")
        print("Yeah, no duh we're gonna do it!")
    input("> ")
    print("King Janoth III:")
    print("Very well, go ahead and meet up with Sergeant Drums.")
    input("> ")
    print("King Janoth III:")
    print("He will assist you.")
    sergeant_life(character_name, player_stats)


def sergeant_life(character_name, player_stats):
    input("> ")
    print("You guys head over to the barracks.")
    input("> ")
    print("Alicia:")
    print("I never expected there to be a barracks in the castle.")
    input("> ")
    print(f"{character_name}:")
    print("Well I'm not suprised.")
    input("> ")
    print("Sergeant Drums:")
    print("I am Sergeant Drums.")
    input("> ")
    print("Sergeant Drums:")
    print("Say, did the king offer you anything?")
    input("> ")
    print("Do you lie or tell the truth?")
    choice_4 = get_choice(["1", "2"], "Choose one: ")
    if choice_4 == "1":
        print(f"{character_name}:")
        print("He offered us 30 Gold each.")
    else:
        print(f"{character_name}:")
        print("He never offered us anything.")
    input("> ")
    print("Sergeant Drums:")
    print("Expected of the king.")
    input("> ")
    print("Sergeant Drums:")
    print("Listen, if you're going to do this...")
    input("> ")
    print("Sergeant Drums")
    print("You'll probably...")
    input("> ")
    print("Alicia:")
    print("We'll probably what?")
    input("> ")
    print("Sergeant Drums:")
    print("Forget it, you don't need to know anyways.")
    input("> ")
    print("Sergeant Drums is acting weird, you have a couple options.")
    print("Intimidate him into telling the truth (Roll an Intimidation check)")
    print("Tell Alicia you don't want to do the quest anymore (Roll a Persuasion check)")
    print("Try to discreetly leave (Roll a Stealth check)")
    print("Stay silent")
    choice_5 = get_choice(["1", "2", "3", "4"], "What will you choose: ")
    if choice_5 == "1":
        dice_roll = get_dice_roll("intimidation")
        if dice_roll > 13:
            print(f"{character_name}:")
            print("I don't appreciate the secrecy.")
            input("> ")
            print("Sergeant Drums:")
            print("Listen we don't have to get aggresive.")
        else:
            print("Sergeant Drums:")
            print("Bahaha, You really think I'm scared of your scrawny ass.")
    elif choice_5 == "2":
        dice_roll = get_dice_roll("persuasion")
        if dice_roll > 13:
            print(f"{character_name}:")
            print("Hey, Alicia can we go?")
            input("> ")
            print("Alicia:")
            print("Sure, we can-")
            input("> ")
            print("Sargeant Drums:")
            print("You guys were hired, you can't just leave")
        else:
            print("Alicia:")
            print(f"Not yet {character_name}")
    elif choice_5 == "3":
        dice_roll = get_dice_roll("stealth")
        if dice_roll > 13:
            print("You successfully sneak out.")
            input("> ")
            print("Maybe you shouldn't have left her behind")
            quit()
        else:
            print("As you try to sneak off Alicia notices you.")
            input("> ")
            print("Alicia:")
            print("Hey! Where do you think you're going?")
    elif choice_5 == "4":
        print("You stand there, watching.")
    else:
        print("Unsure of what to do, you sit down on the floor.")
    input("> ")
    print("Alicia:")
    print("Look, Sergeant if you're not gonna tell us...")
    input(">")
    print("Alicia grabs her sword.")
    input("> ")
    print("Alicia:")
    print("Then we're gonna have to force you.")
    input("> ")
    print("Battle Commenced!")
    first_battle(character_name, player_stats)

def first_battle(character_name, player_stats):
    dice_roll = get_dice_roll("initiative")
    npc_initiative = random.randint(1, 20)
    if dice_roll < npc_initiative:
        print("The enemy goes first!")
        input("> ")
        print("They lunge at you with a sword.")
        npc_hit_chance = random.randint(1, 20)
        npc_damage = random.randint(1, 8)
        input("> ")
        if npc_hit_chance > player_stats["constitution"]:
                print("They hit you.")
                input("> ")
                print(f"They dealt {npc_damage}.")
                player_stats["health"] -= npc_damage
                print(f"You have {player_stats['health']} health")
        else:
            print("They missed their strike")
    elif dice_roll > npc_initiative:
        print("You go first!")
    else:
        print("A tie you guys both clash!")
    input("> ")
    print("You have 2 choices.")
    input("> ")
    print("Heal yourself.")
    print("Attack them relentlessly.")
    battle_choice = get_choice(["1", "2"], "Choose one carefully: ")
    if battle_choice == "1":
        cure_wounds = random.randint(1, 8)
        print("You heal yourself.")
        player_stats["health"] += cure_wounds
        input("> ")
        print(f"You healed {cure_wounds}.")
        input(f"You have {player_stats['health']}.")
        print("You see Alicia charge at the enemy.")
    elif battle_choice == "2":
        print("You lunge at them with your daggers")
        dice_roll = get_dice_roll("attack")
        if dice_roll > 16:
            print("You struck him")
            input("> ")
            print("Roll for damage (1-4)")
            dice_roll = get_dice_roll("damage")
            if dice_roll > 4:
                dmg_roll = random.randint(1, 4)
                print("That's not a valid roll")
                input("> ")
                print("I'll roll for you")
                input("> ")
                print(f"You dealt {dmg_roll} damage!")
            else:
                print(f"You dealt {dice_roll} damage!")
        else:
            print("You missed.")
    else:
        print("You lost your turn for not paying attention.")
    alicia_dmg = random.randint(1, 8)
    npc_damage = random.randint(1, 8)
    print(f"Alicia charges at them and does {alicia_dmg} damage!")
    input("> ")
    print(f"The enemy attacks Alicia, and deals {npc_damage} damage to her!")
    input("> ")
    print("It's your turn.")
    print("Only one option and that's to attack.")
    dice_roll_dmg = get_dice_roll("damage")
    print(f"You dealt {dice_roll_dmg} damage.")
    input("> ")
    if alicia_dmg == 8:
        print("Alicia knocks out the enemy.")
        court(character_name, player_stats)
    else:
        print(f"Alicia did {alicia_dmg} damage!")
        input("> ")
        print("It's you turn.")
        input("> ")
        print("You have 2 choices.")
        choice_6 = get_choice(["1", "2"], "Finish him off, or let him suffer in pain?: ")
        if choice_6 == "1":
            print("You finish him off.")
            input("> ")
            print(f"{character_name}, we needed him y'know that.")
        elif choice_6 == "2":
            print("You do nothing.")
            input("> ")
            print("Alicia sheathes her sword again.")
        else:
            print("You stand there unsure of what to do.")
        court(character_name, player_stats)

def court(character_name, player_stats):
    input("> ")
    print("You and Alicia have been charged, there really was no quest.")

def get_choice(valid_options, prompt="> "):
    while True:
        choice = input(prompt).strip().lower()
        if choice in valid_options:
            return choice
        print(f"Please choose one of the following: {', '.join(valid_options)}")

def get_dice_roll(skill_name="check"):
    while True:
        try:
            roll = int(input(f"What did you roll for your {skill_name} check? "))
            return roll
        except ValueError:
            print("Please enter a valid number.")
