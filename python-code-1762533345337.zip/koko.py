def necromancer(character_name):
    print("Welcome back Koko")
    print("Here are your stats")
    print("Strength: 14")
    print("Dexterity: 18")
    print("Constitution: 16")
    print("Intelligence: 17")
    print("Wisdom: 10")
    print("Charisma: 10")
    print("Here is your character orgin")
    print("You are an Acolyte of Necrosis")
    print("Your role is Cleric/Rogue")
    stats(character_name)
    
def stats(character_name):
    return {
        "strength" : 14,
        "dexterity" : 18,
        "constitution" : 16,
        "intelligence" : 17,
        "wisdom" : 10,
        "charisma" : 10,
        "health": 77
    }